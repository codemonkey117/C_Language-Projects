double getScore();
double getAdjustedAverage(double score1, double score2, double score3);
double highest(double score1, double score2, double score3);
double lowest(double score1, double score2, double score3);