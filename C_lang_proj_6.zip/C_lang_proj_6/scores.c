#include <stdio.h>
#include <stdbool.h>
#include "scores.h"


double getScore()
{ 
  double score;
  while (true)
    { printf("please enter a value between 0-100: ");
  scanf("%lf", &score);
    if (score >= 0 && score <= 100)
    { 
      break;
    }
      printf("Invalid number");
  }
  return score;
}

double highest(double score1, double score2, double score3)
{ 
  double max;
  if (score1 > score2 && score1 > score3)
    max = score1;
  else if (score2 > score1 && score2 > score3)
    max = score2;
  else 
    max = score3;

  return max;
  
}

double lowest(double score1, double score2, double score3)
{ 
  double min;
  if (score1 < score2 && score1 < score3)
    min = score1;
  else if (score2 < score1 && score2 < score3)
    min = score2;
  else 
    min = score3;

  return min;
  }

double getAdjustedAverage(double score1, double score2, double score3)
{
  double lowestScore;
  double highestScore;
  
  double small = lowest(score1, score2, score3);
  double large = highest(score1, score2, score3);
  double avg = (small + large)/2;

  return avg;
  }

