#include <stdio.h>
#include "scores.h"

int main() {
  //get score
  double score1 = 0.00;
  double score2 = 0.00;
  double score3 = 0.00;
  double avg = 0.00;
  
  score1 = getScore();
  score2 = getScore();
  score3 = getScore();

  avg = getAdjustedAverage(score1, score2, score3);

  double lowScore = lowest(score1, score2, score3);
  double highScore = highest(score1, score2, score3);
  
  printf("The average of %.2lf and %.2lf is %.2lf", lowScore, highScore, avg);
  return 0;
}